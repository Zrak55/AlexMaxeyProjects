﻿using System;
using System.Timers;

namespace BruteForcePassword
{
    class Program
    {
        private const string lc = "abcdefghijklmnopqrstuvwxyz";
        private const string uc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        private const string sc = "!@#$%^&*?";
        private const string num = "1234567890";
        private static int seconds;
        private static Timer aTimer;

        static void Main(string[] args)
        {
            Menu();
            aTimer.Dispose();

        }


        static void Menu()
        {
            Random myRan = new Random();

            bool l = false;
            bool u = false;
            bool s = false;
            bool n = false; //used chars
            string usablechars = "";
            int maxLength = 0;
            Console.WriteLine("Welcome to password cracker. \n");
            int x = -1;
            while (x != 5)
            {
                Console.WriteLine("Select an option:\n1: Set usable chars\n2: Set max password length\n3: See current settings\n4: Crack random password\n5: Quit");
                x = Convert.ToInt32(Console.ReadLine());
                switch (x)
                {
                    case 1:
                        SetChars(ref usablechars, ref l, ref u, ref s, ref n);
                        break;
                    case 2:
                        Console.WriteLine("Input new max length: (0-10)");
                        maxLength = Convert.ToInt32(Console.ReadLine());
                        if (maxLength < 0)
                            maxLength = 0;
                        else if (maxLength > 10)
                            maxLength = 10;
                        break;
                    case 3:
                        Console.WriteLine("Allowed characters: " + usablechars + "  Max Length: " + maxLength);
                        break;
                    case 4:
                        crack(usablechars, maxLength, myRan);
                        break;
                    case 5:
                        break;
                    default:
                        Console.WriteLine("Invalid Input");
                        break;
                }
            }


        }

        //password cracking
        static void crack(string chars, int length, Random r)
        {
            Console.WriteLine("Generating random password...");
            string password = generatePassword(length, chars, r);

            seconds = 0;    //resets timer count

            string guess = "";  //declares guess string

            int nc = chars.Length;  //number of characters
            int a, b, c, d, e, f, g, h, i, j;   //loop counters: declared outside of loops to increase efficiency
            Console.WriteLine("Ready: press enter to begin: ");
            Console.ReadLine();

            SetTimer(); //begins the timer

            int cc = 0; //current number of characters: used to ensure we dont go beyond max characters

            //0
            if (checkPassword(password, guess))
                return;
            cc++;
            if (cc <= length)
            {
                //1
                for (a = 0; a < nc; a++)
                {
                    guess = "";
                    guess += chars[a];
                    Console.WriteLine(guess);
                    if (checkPassword(password, guess))
                        return;
                }
                cc++;
                if (cc <= length)
                {
                    //2
                    for (a = 0; a < nc; a++)
                    {
                        for (b = 0; b < nc; b++)
                        {
                            guess = "";
                            guess += chars[a];
                            guess += chars[b];
                            Console.WriteLine(guess);
                            if (checkPassword(password, guess))
                                return;
                        }
                    }
                    cc++;
                    if (cc <= length)
                    {
                        //3
                        for (a = 0; a < nc; a++)
                        {
                            for (b = 0; b < nc; b++)
                            {
                                for (c = 0; c < nc; c++)
                                {
                                    guess = "";
                                    guess += chars[a];
                                    guess += chars[b];
                                    guess += chars[c];
                                    Console.WriteLine(guess);
                                    if (checkPassword(password, guess))
                                        return;
                                }
                            }
                        }
                        cc++;
                        if (cc <= length)
                        {
                            //4
                            for (a = 0; a < nc; a++)
                            {
                                for (b = 0; b < nc; b++)
                                {
                                    for (c = 0; c < nc; c++)
                                    {
                                        for (d = 0; d < nc; d++)
                                        {
                                            guess = "";
                                            guess += chars[a];
                                            guess += chars[b];
                                            guess += chars[c];
                                            guess += chars[d];
                                            Console.WriteLine(guess);
                                            if (checkPassword(password, guess))
                                                return;
                                        }
                                    }
                                }
                            }
                            cc++;
                            if (cc <= length)
                            {
                                //5
                                for(a = 0; a < nc; a++)
                                {
                                    for (b = 0; b < nc; b++)
                                    {
                                        for (c = 0; c < nc; c++)
                                        {
                                            for (d = 0; d < nc; d++)
                                            {
                                                for (e = 0; e < nc; e++)
                                                {
                                                    guess = "";
                                                    guess += chars[a];
                                                    guess += chars[b];
                                                    guess += chars[c];
                                                    guess += chars[d];
                                                    guess += chars[e];
                                                    Console.WriteLine(guess);
                                                    if (checkPassword(password, guess))
                                                        return;
                                                }
                                            }
                                        }
                                    }
                                }
                                cc++;
                                if (cc <= length)
                                {
                                    //6
                                    for (a = 0; a < nc; a++)
                                    {
                                        for (b = 0; b < nc; b++)
                                        {
                                            for (c = 0; c < nc; c++)
                                            {
                                                for (d = 0; d < nc; d++)
                                                {
                                                    for (e = 0; e < nc; e++)
                                                    {
                                                        for (f = 0; f < nc; f++)
                                                        {
                                                            guess = "";
                                                            guess += chars[a];
                                                            guess += chars[b];
                                                            guess += chars[c];
                                                            guess += chars[d];
                                                            guess += chars[e];
                                                            guess += chars[f];
                                                            Console.WriteLine(guess);
                                                            if (checkPassword(password, guess))
                                                                return;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    cc++;
                                    if (cc <= length)
                                    {
                                        //7
                                        for (a = 0; a < nc; a++)
                                        {
                                            for (b = 0; b < nc; b++)
                                            {
                                                for (c = 0; c < nc; c++)
                                                {
                                                    for (d = 0; d < nc; d++)
                                                    {
                                                        for (e = 0; e < nc; e++)
                                                        {
                                                            for (f = 0; f < nc; f++)
                                                            {
                                                                for (g = 0; g < nc; g++)
                                                                {
                                                                    guess = "";
                                                                    guess += chars[a];
                                                                    guess += chars[b];
                                                                    guess += chars[c];
                                                                    guess += chars[d];
                                                                    guess += chars[e];
                                                                    guess += chars[f];
                                                                    guess += chars[g];
                                                                    Console.WriteLine(guess);
                                                                    if (checkPassword(password, guess))
                                                                        return;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        cc++;
                                        if (cc <= length)
                                        {
                                            //8
                                            for (a = 0; a < nc; a++)
                                            {
                                                for (b = 0; b < nc; b++)
                                                {
                                                    for (c = 0; c < nc; c++)
                                                    {
                                                        for (d = 0; d < nc; d++)
                                                        {
                                                            for (e = 0; e < nc; e++)
                                                            {
                                                                for (f = 0; f < nc; f++)
                                                                {
                                                                    for (g = 0; g < nc; g++)
                                                                    {
                                                                        for (h = 0; h < nc; h++)
                                                                        {
                                                                            guess = "";
                                                                            guess += chars[a];
                                                                            guess += chars[b];
                                                                            guess += chars[c];
                                                                            guess += chars[d];
                                                                            guess += chars[e];
                                                                            guess += chars[f];
                                                                            guess += chars[g];
                                                                            guess += chars[h];
                                                                            Console.WriteLine(guess);
                                                                            if (checkPassword(password, guess))
                                                                                return;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            cc++;
                                            if (cc <= length)
                                            {
                                                //9
                                                for (a = 0; a < nc; a++)
                                                {
                                                    for (b = 0; b < nc; b++)
                                                    {
                                                        for (c = 0; c < nc; c++)
                                                        {
                                                            for (d = 0; d < nc; d++)
                                                            {
                                                                for (e = 0; e < nc; e++)
                                                                {
                                                                    for (f = 0; f < nc; f++)
                                                                    {
                                                                        for (g = 0; g < nc; g++)
                                                                        {
                                                                            for (h = 0; h < nc; h++)
                                                                            {
                                                                                for (i = 0; i < nc; i++)
                                                                                {
                                                                                    guess = "";
                                                                                    guess += chars[a];
                                                                                    guess += chars[b];
                                                                                    guess += chars[c];
                                                                                    guess += chars[d];
                                                                                    guess += chars[e];
                                                                                    guess += chars[f];
                                                                                    guess += chars[g];
                                                                                    guess += chars[h];
                                                                                    guess += chars[i];
                                                                                    Console.WriteLine(guess);
                                                                                    if (checkPassword(password, guess))
                                                                                        return;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                cc++;
                                                if (cc <= length)
                                                {
                                                    //9
                                                    for (a = 0; a < nc; a++)
                                                    {
                                                        for (b = 0; b < nc; b++)
                                                        {
                                                            for (c = 0; c < nc; c++)
                                                            {
                                                                for (d = 0; d < nc; d++)
                                                                {
                                                                    for (e = 0; e < nc; e++)
                                                                    {
                                                                        for (f = 0; f < nc; f++)
                                                                        {
                                                                            for (g = 0; g < nc; g++)
                                                                            {
                                                                                for (h = 0; h < nc; h++)
                                                                                {
                                                                                    for (i = 0; i < nc; i++)
                                                                                    {
                                                                                        for (j = 0; j < nc; j++)
                                                                                        {
                                                                                            guess = "";
                                                                                            guess += chars[a];
                                                                                            guess += chars[b];
                                                                                            guess += chars[c];
                                                                                            guess += chars[d];
                                                                                            guess += chars[e];
                                                                                            guess += chars[f];
                                                                                            guess += chars[g];
                                                                                            guess += chars[h];
                                                                                            guess += chars[i];
                                                                                            guess += chars[j];
                                                                                            Console.WriteLine(guess);
                                                                                            if (checkPassword(password, guess))
                                                                                                return;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                    }
                                    
                                }
                            }
                        }

                    }
                }

            }
        }

        static bool checkPassword(string p, string g)
        {
            bool ret = p == g;
            if (ret)
            {
                Console.WriteLine("Found!");
                Console.WriteLine("Seconds Elapsed: " + seconds);
                aTimer.Stop();
            }
            return ret;
        }

        static void SetChars(ref string c, ref bool l, ref bool u, ref bool s, ref bool n)
        {
            int z = -1;
            Console.WriteLine("Enter Numbers to add or remove the characters: 1: UpperCase  2: LowerCase  3: SpecialCharacters  4: Numbers  5: Stop");
            
            while (z != 5)
            {
                Console.WriteLine(c);
                z = Convert.ToInt32(Console.ReadLine());
                switch (z)
                {
                    case 1:
                        u = !u;
                        break;
                    case 2:
                        
                        l = !l;
                        break;
                    case 3:
                        s = !s;
                        break;
                    case 4:
                        n = !n;
                        break;
                    case 5:
                        break;
                    default:
                        Console.WriteLine("Invalid");
                        break;
                }
                c = buildString(u, l, s, n);
            }
        }

        static string buildString(bool a, bool b, bool c, bool d)
        {
            string ret = "";
            if (a)
                ret += uc;
            if (b)
                ret += lc;
            if (c)
                ret += sc;
            if (d)
                ret += num;
            return ret;
        }

        static string generatePassword(int l, string chars, Random r)
        {
            string p = "";
            int len = r.Next(1, l+1);
            for(int i = 0; i<len; i++)
            {
                int c = r.Next(0, chars.Length);
                p += chars[c];
            }

            return p;
        }


        private static void SetTimer()
        {
            // Create a timer with a two second interval.
            aTimer = new System.Timers.Timer(1000);
            // Hook up the Elapsed event for the timer. 
            aTimer.Elapsed += OnTimedEvent;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;
        }

        private static void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            seconds++;
        }

    }

    


}


